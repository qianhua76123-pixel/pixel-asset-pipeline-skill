#!/usr/bin/env python3
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1]
V46=R.parent/'nancun-occlusion-events-v46/godot-demo'
V62=R.parent/'nancun-godot-continuous-bones-v62'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=['scripts/rig_math.gd','scripts/action_timeline.gd','scripts/occlusion_track.gd','scripts/equipment_contract.gd','scripts/final_plan_adapter.gd','data/action-events.json','data/occlusion-tracks.json','data/occlusion-policy.json','data/equipment-contract.json','assets/runtime-data.json']
rows=[]
for p in paths:
 row={'file':p,'source':str(V46/p),'sourceSha256':sha(V46/p),'sha256':sha(R/p)};row['exact']=row['sourceSha256']==row['sha256'];assert row['exact'];rows.append(row)
source=json.loads((V62/'data/rig-export.json').read_text());binding=json.loads((R/'data/body-bindings.json').read_text())
for k in ['defs','restFrames','parts','outfits']:assert binding[k]==source[k]
images=json.loads((R/'qa/assets-preservation.json').read_text())
# Check runtime render code loads native parts, and full-body outputs are only QA products.
report={'runtimeModulesCopiedFromV46':rows,'bindingSource':{'file':str(V62/'data/rig-export.json'),'sha256':sha(V62/'data/rig-export.json'),'derivedFile':'data/body-bindings.json','derivedSha256':sha(R/'data/body-bindings.json'),'identicalSelectedFields':['defs','restFrames','parts','outfits'],'unusedSampledPlansAndPosesRemoved':not any(k in binding for k in ['poses','plans'])},'pixelPreservationReport':'qa/assets-preservation.json','renderInput':'71 individual native PNG pieces only; no rendered wholebody atlases or QA PNG inputs','scope':'front heqing/original+stone-blue-daily+moon-celadon-hanfu; idle/sword/hoe; original RGB'}
(R/'qa/source-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('10 frozen V46 modules/data exact; selected V62 binding fields exact')

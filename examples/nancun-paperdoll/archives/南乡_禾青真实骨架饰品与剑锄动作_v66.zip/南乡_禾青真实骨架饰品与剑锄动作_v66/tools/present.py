#!/usr/bin/env python3
"""Presentation only: integer nearest PNG enlargement and actual GPU-frame GIF."""
from pathlib import Path
import json, hashlib
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parents[1]
F='/System/Library/Fonts/STHeiti Light.ttc'
font=ImageFont.truetype(F,22)
small=ImageFont.truetype(F,16)
bg=(242,237,222)
report=json.loads((R/'qa/demo-render.json').read_text())
outputs=[]
for action,title in [('sword','挥剑'),('hoe','挥锄')]:
 for structure in [False,True]:
  rows=[x for x in report['frames'] if x['action']==action and x['structure']==structure]
  images=[];durations=[]
  for x in rows:
   im=Image.new('RGB',(1152,440),bg);d=ImageDraw.Draw(im)
   for i,name in enumerate(['原衣装','石青日常','月白豆青汉服']):d.text((i*384+20,14),name,font=font,fill=(55,65,58))
   raw=Image.open(R/x['file']).convert('RGBA').resize((1152,384),Image.Resampling.NEAREST);im.paste(raw,(0,46),raw)
   images.append(im);durations.append(max(20,round(x['durationMs']/10)*10))
  path=R/'presentation'/f"{action}-{'bones' if structure else 'clean'}.gif"
  images[0].save(path,save_all=True,append_images=images[1:],duration=durations,loop=0,disposal=2,optimize=False)
  # Adjacent identical RGBA frames can be coalesced by GIF encoder; durations remain >=20ms.
  with Image.open(path) as g:
   actual=[]
   for i in range(g.n_frames):g.seek(i);actual.append(g.info['duration'])
  assert min(actual)>=20
  outputs.append({'file':str(path.relative_to(R)),'sourceGPUFrames':len(rows),'encodedFrames':len(actual),'minimumFrameMs':min(actual),'totalDurationMs':sum(actual),'renderSource':'Bone2D scene','formatTiming':'GIF times quantized to 10 ms; source timing preserved in demo-render.json'})
# Exact flat-vs-bone pairs at actual selected native GPU frames.
qa=json.loads((R/'qa/gpu-baseline.json').read_text());selected=[0,8,21,39,75,93]
out=Image.new('RGB',(1152,800),bg);d=ImageDraw.Draw(out)
for cell,n in enumerate(selected):
 item=qa['samples'][n];x=(cell%3)*384;y=(cell//3)*400
 d.text((x+10,y+8),f"{item['action']} · {item['phase']:g}",font=font,fill=(55,65,58))
 for side,kind in enumerate(['flat','bone']):
  a=Image.open(R/'qa/gpu'/f'{n:03}-{kind}.png').convert('RGBA').resize((192,192),Image.Resampling.NEAREST)
  out.paste(a,(x+side*192,y+70),a);d.text((x+side*192+12,y+42),'最终平面计划' if side==0 else '真实骨节点',font=small,fill=(55,65,58))
 d.text((x+12,y+280),item['outfit'],font=small,fill=(55,65,58));d.text((x+12,y+312),f"RGBA 差异：{item['rgbaChangedPixels']}",font=small,fill=(55,65,58))
out.save(R/'presentation/flat-vs-bones.png')
(R/'qa/presentation.json').write_text(json.dumps({'outputs':outputs,'note':'No new art or wholebody input; native GPU output is enlarged with NEAREST only.'},indent=2,ensure_ascii=False)+'\n')
print('\n'.join(x['file'] for x in outputs))

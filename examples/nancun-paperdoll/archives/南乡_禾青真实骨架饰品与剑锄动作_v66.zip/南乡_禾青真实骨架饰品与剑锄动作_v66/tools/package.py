#!/usr/bin/env python3
"""Freeze, CRC/byte-verify, and fresh-import smoke an isolated V66 delivery."""
from pathlib import Path
import hashlib,json,subprocess,tempfile,zipfile,datetime,os
R=Path(__file__).resolve().parents[1]
ZIP=R.parent/'南乡_禾青真实骨架饰品与剑锄动作_v66.zip'
NAME=ZIP.stem
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def files():
 return sorted(p for p in R.rglob('*') if p.is_file() and '.godot' not in p.parts and '__pycache__' not in p.parts and p.name!='.DS_Store' and not p.name.endswith('.import'))
excluded={'qa/freeze.json','qa/package-verification.json'}
entries=[{'file':str(p.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size} for p in files() if str(p.relative_to(R)) not in excluded]
(R/'qa/freeze.json').write_text(json.dumps({'version':'v66','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'frozen-mechanism-candidate','excludedSelfOrPackagingReports':sorted(excluded),'files':entries},ensure_ascii=False,indent=2)+'\n')
if (R/'qa/package-verification.json').exists():(R/'qa/package-verification.json').unlink()
def write_zip():
 with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in files():z.write(p,str(Path(NAME)/p.relative_to(R)))
write_zip()
with tempfile.TemporaryDirectory(prefix='nancun-v66-fresh-') as temp:
 with zipfile.ZipFile(ZIP) as z:
  assert z.testzip() is None
  for item in z.infolist():assert z.read(item)==(R/Path(item.filename).relative_to(NAME)).read_bytes()
  z.extractall(temp)
 extracted=Path(temp)/NAME
 results=[]
 for args in [['--headless','--editor','--import'],['--headless','--quit-after','3']]:
  proc=subprocess.run(['godot-4.6.2','--path',str(extracted),*args],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
  result={'command':['godot-4.6.2','--path','<fresh-extraction>',*args],'exitCode':proc.returncode,'containsErrors':any(x in proc.stdout for x in ['SCRIPT ERROR:','ERROR:','Parse Error:']),'output':proc.stdout}
  results.append(result);assert result['exitCode']==0 and not result['containsErrors'],proc.stdout
 report={'zip':str(ZIP),'freshExtraction':True,'priorGodotCacheCopied':False,'smoke':results,'crcPassed':True,'allArchiveEntriesEqualFrozenRootBytes':True,'notRepeated':'112 GPU cases are not rerun by packaging smoke','packageVerificationNotSelfHashed':True}
 (R/'qa/package-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
# Only the receipt is new; runtime/assets unchanged from fresh smoke.
write_zip()
with zipfile.ZipFile(ZIP) as z:
 assert z.testzip() is None
 for item in z.infolist():assert z.read(item)==(R/Path(item.filename).relative_to(NAME)).read_bytes()
 count=len(z.infolist())
print(json.dumps({'zip':str(ZIP),'sha256':sha(ZIP),'bytes':ZIP.stat().st_size,'entries':count,'frozenFiles':len(entries),'CRC':'passed','eachEntry':'byte-exact','freshImportAndMainSmoke':'passed'},ensure_ascii=False,indent=2))

#!/bin/zsh
set -e
cd -- "${0:A:h}"
GODOT_BIN="$HOME/Applications/Godot-4.6.2.app/Contents/MacOS/Godot"
if [[ ! -x "$GODOT_BIN" ]]; then
  GODOT_BIN="$(command -v godot-4.6.2 || true)"
fi
if [[ -z "$GODOT_BIN" || ! -x "$GODOT_BIN" ]]; then
  print '请先安装 Godot 4.6.2，再用编辑器打开本目录 project.godot。此脚本不会下载软件。'
  read '?按回车关闭'; exit 1
fi
"$GODOT_BIN" --headless --path . --editor --import
exec "$GODOT_BIN" --path .

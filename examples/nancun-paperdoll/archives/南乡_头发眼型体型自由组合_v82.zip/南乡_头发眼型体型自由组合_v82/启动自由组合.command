#!/bin/zsh
set -e
TASK_DIR="${0:A:h}"
cd "$TASK_DIR/runtime"
print '南乡自由组合：http://127.0.0.1:3450/'
print '请在浏览器打开上方地址。关闭本窗口会停止本次预览服务。'
python3 -m http.server 3450 --bind 127.0.0.1

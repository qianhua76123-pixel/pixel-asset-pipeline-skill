/* Isolated body-registration adapter. It never edits source textures, sourceBone, clocks or input plans. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.BodyProfiles=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';const clone=x=>JSON.parse(JSON.stringify(x));
function applyToCharacter(character,profile){
 const c=clone(character);if(!profile||!['standard','solid'].includes(profile.id))throw Error('Unknown body profile');
 if(!profile.bindPoses?.down?.joints)throw Error('Complete down bind required');
 for(const [name,p]of Object.entries(profile.bindPoses.down.joints))if(!Array.isArray(p)||p.length!==2||!p.every(Number.isFinite))throw Error('Invalid bind joint '+name);
 c.bindPoses={...c.bindPoses,down:clone(profile.bindPoses.down)};const by=new Map(c.attachments.map(p=>[p.id,p]));
 for(const[id,o]of Object.entries(profile.attachmentOverrides||{})){
  const p=by.get(id);if(!p)throw Error('Unknown body attachment '+id);
  if(Object.keys(o).some(k=>!['widthFactor','rigidWidthFactor'].includes(k)))throw Error('Unsupported body override');
  if(o.widthFactor!==undefined&&o.rigidWidthFactor!==undefined)throw Error('Double body scaling');
  const f=o.widthFactor??o.rigidWidthFactor;if(!Number.isFinite(f)||f<.8||f>1.4)throw Error('Invalid garment width');
  if(o.widthFactor!==undefined){if(!p.sourceBone||!p.targetBone)throw Error('Normal width requires source and target bone');p.widthFactor=o.widthFactor;}
  if(o.rigidWidthFactor!==undefined&&(!p.pivot||p.bindJoint!=='pelvis'||p.sourceBone))throw Error('Rigid width requires pelvis-only attachment');
 }
 return c;
}
function registerCommands(commands,character,profile){
 const by=new Map(character.attachments.map(p=>[p.id,p]));
 return commands.map(command=>{const result={...command,matrix:command.matrix.slice()},o=profile.attachmentOverrides?.[command.id];if(o?.rigidWidthFactor!==undefined){
  const p=by.get(command.id);if(!p||p.sourceBone||p.bindJoint!=='pelvis'||!p.pivot)throw Error('Invalid rigid registration');
  const f=o.rigidWidthFactor,[a,b,c,d,e,g]=result.matrix,px=p.pivot[0];
  // M * T(pivot) * Scale(f, 1) * T(-pivot): target pelvis stays fixed, mask uses exactly this matrix.
  result.matrix=[a*f,b*f,c,d,e+a*(1-f)*px,g+b*(1-f)*px];
 }return result;});
}
return {applyToCharacter,registerCommands};
});

# 禾青衣装包 · v15

本接口更换真实衣料裁片，共用当前人物的头、前辫、手、鞋及动作时钟。它没有裸体全身底模，不能从任意完整人物图自动恢复遮挡身体。新角色仍仅正面。

## 包格式

`outfit.json` 路径由命令传入；PNG 文件相对该 JSON 所在目录。所有 PNG 必须是原始坐标的完整 64×64、二值 alpha，不做自动 fit 或 resize。

```json
{
  "version": 1,
  "character": "heqing",
  "id": "moon-celadon-hanfu",
  "name": "月白豆青",
  "directions": ["down"],
  "baseCharacterSourceSha256": "源禾青 source.png 的 SHA256",
  "attachments": [],
  "parts": ["每个真实 attachment 的唯一 ID"]
}
```

本轮 ID：`original` 保留；`stone-blue-daily` 石青日常；`moon-celadon-hanfu` 月白豆青。未交完整文件的 ID 只记录在 `assets/outfit-catalog.json`，不进人物可选衣装或界面按钮。

每个 attachment：

- 必需 `id`、`part`、`category`（等于衣装 ID）、`direction:'down'`、`file`、`sha256`、`dyeMask`。
- 通常用 `sourceBone` 加 `targetBone`。两端原坐标必须等于人物相应 bind joints；不迁移手腕去适配衣服源图。
- 裙片用 `part:'skirt'`、`bindJoint:'pelvis'`、`pivot:[32,48.5]`，不写 `sourceBone`。高腰的像素仍保留高腰位置；pivot 表示变换原点，不把腰线拉到骨盆。
- 可选 `underlap:true`、`drawOrder`。不提供新字段时沿用已冻结排序。
- 可选 `layerOrder` 覆盖自动排序，数值小的先画。导入衣料必须小于 50，保持手前景；建议裙 25、腰带 35、袖 45。shared 手 50、头 80、前辫 90 保持不变；underlap 默认 -1000。
- `dyeGroup:'top'|'bottom'|'trim'` 控制整片默认分区。露肤小片的 `dyeMask` 必须全透明，仍要显式声明；不能把新衣片中皮肤纳入染色。
- 单片存在不同材料时可选 `dyeChannels:{top:'mask.png',trim:'mask.png'}`；这些蒙版必须互斥且在本片 `dyeMask` 内。不要仅为填满 UI 新造不存在的衣缘分区。
- 可选 `dyeMaskSha256` 与 `dyeChannelSha256:{top:'sha',trim:'sha'}`。导入后所有蒙版都会记录最终 SHA。

不能用 `head/hairFront/handA/handB/shoeA/shoeB` 作为新衣片的 part。原露臂/脚踝需要的皮肤片，可保留源像素，使用对应 `lowerArmA/B` 或 `shinA/B`，配全透明染色蒙版与原骨绑定。不能整片保留旧上衣作为新衣装下面的兜底。

## 接入与检查

在 runtime 目录运行：

```sh
python3 tools/import-outfit.py --package ../hanfu/package/outfit.json --check-only
python3 tools/import-outfit.py --package ../hanfu/package/outfit.json
python3 tools/bundle-live.py
python3 tools/test-outfit-extension.py
```

已有同 ID 的明确修订包需加 `--replace`。工具先验证全部文件，再复制到 `assets/outfits/<id>/` 并注册该衣装；不请求生成服务、不编辑原 PNG 像素。源 SHA、导入文件 SHA 与共享附件不变检查记录在 `qa/import-<id>.json`。原 bundle 在重建前保持旧内容，完整重建后才对页面可见。

静止合成必须另与衣装作者提供的目标图逐 RGBA 对照，再检查 8 个关键姿势及连续动作。导入通过只证明机械合同，不能代替接缝与造型实看。

## 运行时选项

```js
{ character:'heqing', outfit:'moon-celadon-hanfu',
  palette:'original', dye:{top:'linen',bottom:'moss',trim:'original'},
  action:'hoe', phase:3.25, equipment:{hand:'wood-hoe'} }
```

`palette` 保持旧版整体色调；`dye` 中缺省项沿用整体色调，`original` 明确保留该区原色。色板仍只有原色/靛蓝/苔绿/赭棕/浅麻。染色继续乘原有亮度，不改变 alpha、轮廓或皮肤保护。换衣和各区染色不会修改 phase、blinkTimeMs、装备、骨角或共享部件。

这是刚性裁片，不是裙摆网格权重或布料模拟。大幅动作必须看实际袖口、前辫遮挡和裙下腿部，不因 FK 数学通过就宣称成品。

## 仅明确新衣料启用的深色材质映射

石青日常裤布使用显式 `dyeProfile`；原衣装、旧 B 与没有该字段的附件继续走旧算法。原色模式始终返回原 RGB，不量化源 PNG。

```json
{"mode":"material-ramp","protectMaxRgb":40,"sourceLumaStops":[43,60],"targetFactors":[0.38,0.62,0.86]}
```

仅在本片保护 `dyeMask` 内生效；RGB 最大通道 ≤40 的最深轮廓保留原色。其余裤布以原像素亮度分成暗/中/亮三段，分别乘目标色板 0.38/0.62/0.86，保留色阶而让深裤中间色可换成靛蓝或苔绿。此阈值是本款裤布的显式材料约定，不推广为全局默认或自动判断所有外轮廓。

当前静止真实输出：仅上装改变 102 个布料像素；仅下装改变 47 个；已核查的 45 个最深轮廓像素和 440 个受保护身体像素均零变化。以 `qa/outfits/stone-blue-daily/runtime-review.json` 为准；还需对应图片实看。

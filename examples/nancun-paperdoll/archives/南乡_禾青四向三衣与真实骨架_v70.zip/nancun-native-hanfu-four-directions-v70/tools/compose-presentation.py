#!/usr/bin/env python3
"""Compose real Godot GPU captures at exact integer scale; never modifies source assets."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, hashlib
import numpy as np
R=Path(__file__).resolve().parent.parent
P=R/'presentation';inputs=R/'qa/presentation-frames'
font_path=next(p for p in [Path('/System/Library/Fonts/PingFang.ttc'),Path('/System/Library/Fonts/Supplemental/Arial Unicode.ttf')] if p.exists())
font=ImageFont.truetype(str(font_path),20)
small=ImageFont.truetype(str(font_path),16)
bg=(241,235,220);ink=(49,58,47)
directions=[('down','正面'),('right','向右'),('up','背面'),('left','向左')]
outfits=[('original','原版衣服'),('stone-blue-top-four-view','石青日常上衣 · 原裤原鞋'),('moon-celadon-four-view','月白青瓷汉服 · 刚性裙片')]
def label(im,pos,txt,f=font):
 mask=Image.new('L',im.size);ImageDraw.Draw(mask).text(pos,txt,font=f,fill=255)
 im.paste(ink,(0,0,*im.size),mask.point(lambda v:255 if v>=128 else 0))
def place(im,file,xy,scale=3,crop=False):
 native=Image.open(file).convert('RGBA')
 if crop:native=native.crop((16,16,80,80))
 view=native.resize((native.width*scale,native.height*scale),Image.Resampling.NEAREST)
 im.paste(view,xy,view)
def board(frame):
 im=Image.new('RGB',(1152,1058),bg)
 label(im,(20,8),'V70 · 四方向共骨、三衣共动作 · 0.8 秒原地行走')
 label(im,(20,38),'真实 Godot 14 身体骨 + 1 裙骨 / 静态裁片；96×96 视口同比放大 3×',small)
 for row,(outfit,name) in enumerate(outfits):
  y=72+row*326;label(im,(20,y),name)
  for col,(direction,title) in enumerate(directions):
   label(im,(col*288+118,y+28),title,small)
   place(im,inputs/f'{outfit}-{direction}-{frame:02}.png',(col*288,y+48))
 return im
colors={bg,ink}
for p in inputs.glob('*.png'):
 colors.update(tuple(c[:3]) for c in Image.open(p).convert('RGBA').getdata() if c[3])
assert len(colors)<=256,len(colors)
palette_colors=sorted(colors);raw=[v for c in palette_colors for v in c]
codes=np.array([(r<<16)|(g<<8)|b for r,g,b in palette_colors],dtype=np.uint32)
def indexed(im):
 a=np.asarray(im,dtype=np.uint32);values=(a[:,:,0]<<16)|(a[:,:,1]<<8)|a[:,:,2];indices=np.searchsorted(codes,values)
 assert np.array_equal(codes[indices],values)
 result=Image.fromarray(indices.astype(np.uint8));result.putpalette(raw+[0]*(768-len(raw)));return result
frames=[indexed(board(i)) for i in range(40)]
gif=P/'four-directions-three-outfits-800ms.gif'
frames[0].save(gif,save_all=True,append_images=frames[1:],duration=[20]*40,loop=0,optimize=False,disposal=1)
proof=Image.open(gif);delays=[]
for i in range(proof.n_frames):
 proof.seek(i);delays.append(proof.info['duration'])
 assert proof.convert('RGB').tobytes()==board(i).tobytes()
assert proof.n_frames==40 and delays==[20]*40
board(12).save(P/'four-directions-three-outfits-contact.png')
for outfit,name in outfits:
 im=Image.new('RGB',(1536,892),bg);label(im,(16,8),name+' · 四向 8 个关键相位 · 原生 64 画布放大 3×')
 for row,(direction,title) in enumerate(directions):
  y=44+row*212;label(im,(12,y),title,small)
  for key in range(8):
   label(im,(key*192+89,y),str(key+1),small)
   place(im,R/'qa/gpu'/f'{direction}-{outfit}-walk-{key}.0-bones.png',(key*192,y+22),3,True)
 im.save(P/f'{outfit}-four-directions-eight-keys.png')
neutral=Image.new('RGB',(1024,1008),bg);label(neutral,(16,8),'三款衣装 · 四向中立重组 · 原生 64 画布放大 4×')
for row,(outfit,name) in enumerate(outfits):
 y=44+row*320;label(neutral,(16,y),name,small)
 for col,(direction,title) in enumerate(directions):
  label(neutral,(col*256+104,y+24),title,small)
  place(neutral,R/'qa/gpu'/f'{direction}-{outfit}-neutral-0.0-bones.png',(col*256,y+44),4,True)
neutral.save(P/'neutral-four-directions-three-outfits.png')
report={'source':'Actual Godot 4.6.2 GPU capture; no new artwork or native image edits','viewports':12,'sourceFrames':480,'phaseSamples':40,'phaseStep':.2,'gifStoredFrames':40,'gifFrameMs':delays,'gifCycleMs':800,'minimumFrameMs':20,'globalPaletteColors':len(colors),'decodedRgbExact':True,'nearestIntegerScale':3,'gifSha256':hashlib.sha256(gif.read_bytes()).hexdigest(),'limitations':['In-place demonstration only; no movement, foot locking or transition claim.','Static screenshots and GPU agreement do not establish animation naturalness.','Stone blue changes only tops; Hanfu replaces trousers with authored rigid skirt pieces.']}
(R/'qa/presentation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='gifFrameMs'},ensure_ascii=False))

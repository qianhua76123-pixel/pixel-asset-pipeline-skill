#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json,zipfile,tempfile,subprocess
R=Path(__file__).resolve().parent.parent
ZIP=R.parent/'南乡_禾青四向三衣与真实骨架_v70.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()
def allowed(p):
 rel=p.relative_to(R)
 return p.is_file() and not any(x in {'.godot','__pycache__','.DS_Store'} for x in rel.parts) and rel.as_posix() not in {'qa/freeze.json','qa/package-validation.json'} and not p.name.endswith('.pyc')
files={p.relative_to(R).as_posix():sha(p.read_bytes()) for p in sorted(R.rglob('*')) if allowed(p)}
freeze={'status':'frozen-native-four-view-three-outfit-candidate','frozenAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bones':15,'bodyBones':14,'rigidSkirtBones':1,'sprites':195,'directions':['down','right','up','left'],'outfits':['original','stone-blue-top-four-view','moon-celadon-four-view'],'default':'original','actions':['idle','walk'],'sourcePngByteExact':195,'logicChecks':33,'gpuChecks':35,'gpuCasesRgbaExact':180,'independentFocusedChecks':0,'walkJointSamplesPerDirection':128,'idleJointSamplesPerDirection':5,'gifFrames':40,'gifFrameMs':20,'gifCycleMs':800,'newGenerationCalls':0,'wholeBodyFrameResourcesInRuntime':0,'limits':['in-place only; no world movement or transition','original colors/head only; no equipment/dye/face editor; rigid skirt is not cloth','native skeletal portability is verified, not improved motion naturalness','runtime solver overrides manually edited bone poses'],'files':files,'fileCount':len(files)}
(R/'qa/freeze.json').write_text(json.dumps(freeze,ensure_ascii=False,indent=2)+'\n')
included=[R/p for p in files]+[R/'qa/freeze.json']
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in included:z.write(p,R.name+'/'+p.relative_to(R).as_posix())
unpack=Path(tempfile.mkdtemp(prefix='nancun-v70-unpack-'))
with zipfile.ZipFile(ZIP) as z:
 assert z.testzip() is None
 assert not any('/.godot/' in x for x in z.namelist())
 for p in included:assert z.read(R.name+'/'+p.relative_to(R).as_posix())==p.read_bytes()
 z.extractall(unpack)
fresh=unpack/R.name
assert not (fresh/'.godot').exists()
for p in included:assert (fresh/p.relative_to(R)).read_bytes()==p.read_bytes()
godot='/Users/qian/Applications/Godot-4.6.2.app/Contents/MacOS/Godot'
imported=subprocess.run([godot,'--headless','--path',str(fresh),'--editor','--import','--quit'],capture_output=True,text=True,timeout=60)
assert imported.returncode==0,(imported.stdout,imported.stderr)
assert not any(x in imported.stderr for x in ['ERROR:','SCRIPT ERROR:']),imported.stderr
smoke=subprocess.run([godot,'--headless','--path',str(fresh),'--script','tools/smoke_delivery.gd'],capture_output=True,text=True,timeout=30)
assert smoke.returncode==0,(smoke.stdout,smoke.stderr)
assert not any(x in smoke.stderr for x in ['ERROR:','SCRIPT ERROR:']),smoke.stderr
line=next(s for s in smoke.stdout.splitlines() if s.startswith('V70_SMOKE '))
smoke_report=json.loads(line[len('V70_SMOKE '):]);assert smoke_report['failures']==0
after_changed=[p.relative_to(R).as_posix() for p in included if (fresh/p.relative_to(R)).read_bytes()!=p.read_bytes()]
assert not after_changed,after_changed
report={'status':'verified','zip':str(ZIP),'zipSha256':sha(ZIP.read_bytes()),'zipBytes':ZIP.stat().st_size,'files':len(included),'crcVerified':True,'everyArchiveFileByteExact':True,'freshExtractionByteExact':True,'freshImportExit':imported.returncode,'freshImportNoScriptErrors':True,'freshSmoke':smoke_report,'includedFilesChangedByFreshImport':after_changed,'cacheExcluded':True,'unpackDirectory':str(fresh)}
(R/'qa/package-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))

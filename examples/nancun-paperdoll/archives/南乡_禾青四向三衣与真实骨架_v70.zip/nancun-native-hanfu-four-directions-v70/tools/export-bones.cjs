'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('node:assert/strict'),crypto=require('crypto');
const R=path.resolve(__dirname,'..'),V=path.resolve(R,'../nancun-hanfu-four-directions-integrated-v69/technical'),E=require(V+'/rig-engine.js');
const ctx={window:{}};vm.runInNewContext(fs.readFileSync(V+'/bundle-data.js','utf8'),ctx);
const source=JSON.parse(JSON.stringify(ctx.window.RIG_LIVE_BUNDLE)),scene=E.createSceneModel(source),c=scene.characters.get('heqing');
const directions=['down','right','up','left'],outfitIds=['original','stone-blue-top-four-view','moon-celadon-four-view'];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),clone=x=>JSON.parse(JSON.stringify(x)),len=(a,b)=>Math.hypot(b[0]-a[0],b[1]-a[1]);
const mul=(a,b)=>[a[0]*b[0]+a[2]*b[1],a[1]*b[0]+a[3]*b[1],a[0]*b[2]+a[2]*b[3],a[1]*b[2]+a[3]*b[3],a[0]*b[4]+a[2]*b[5]+a[4],a[1]*b[4]+a[3]*b[5]+a[5]],tr=p=>[1,0,0,1,...p];
const defs=[{id:'Root',parent:null,joint:'root'},{id:'Pelvis',parent:'Root',joint:'pelvis'},{id:'RigidPelvis',parent:'Pelvis',joint:'pelvis',rigidAngle:true},{id:'Torso',parent:'Pelvis',pair:['neck','pelvis']},{id:'HeadUpright',parent:'Root',head:true},...['A','B'].flatMap(s=>[{id:'UpperArm'+s,parent:'Torso',pair:['shoulder'+s,'elbow'+s]},{id:'Forearm'+s,parent:'UpperArm'+s,pair:['elbow'+s,'wrist'+s]},{id:'Thigh'+s,parent:'Pelvis',pair:['hip'+s,'knee'+s]},{id:'Shin'+s,parent:'Thigh'+s,pair:['knee'+s,'ankle'+s]},{id:'Foot'+s,parent:'Shin'+s,pair:['ankle'+s,'toe'+s]}])];
const views={},parts=[],textures={},poseRefs=[],gpuRefs=[],neutralRefs=[];let maxFactoredMatrixError=0;
for(const direction of directions){
 const rest=E.bindPose(scene,'heqing',direction),j=rest.joints;
 const viewDefs=defs.map(d=>({...d,restLength:d.pair?len(j[d.pair[0]],j[d.pair[1]]):4}));
 function frames(p){const globals={},locals={};for(const d of viewDefs){let f;if(d.head)f=tr(j.head.map((v,i)=>v+E.roundEven(p.joints.head[i]-v)));else if(d.pair){const a=p.joints[d.pair[0]],b=p.joints[d.pair[1]],l=len(a,b),dx=b[0]-a[0],dy=b[1]-a[1];assert(l>.1);f=[dx/d.restLength,dy/d.restLength,-dy/l,dx/l,...a];}else if(d.rigidAngle){const a=(p.torsoAngle||0)*Math.PI/180;f=[Math.cos(a),Math.sin(a),-Math.sin(a),Math.cos(a),...p.joints[d.joint]];}else f=tr(p.joints[d.joint]);globals[d.id]=f;locals[d.id]=d.parent?mul(E.inverse(globals[d.parent]),f):f;}return {globals,locals};}
 views[direction]={defs:viewDefs,restFrames:frames(rest),bind:j,legacy:Array.from({length:8},(_,k)=>E.poseAtPhase(scene.legacy,direction,k).worldJoints),projection:{down:[0,.5],right:[1,0],up:[0,-.5],left:[-1,0]}[direction]};
 const restPlans=Object.fromEntries(outfitIds.map(id=>[id,E.customCommands(c,direction,id,rest,'open','original')]));
 const active=new Set(Object.values(restPlans).flat().map(cmd=>cmd.id));
 for(const p of c.attachments.filter(p=>active.has(p.id))){
  let bone,local;
  if(['head','hairFront'].includes(p.part)){bone='HeadUpright';local=tr(j.head.map(v=>-v));}
  else if(p.sourceBone&&p.targetBone){const d=viewDefs.find(d=>d.pair&&d.pair.join('/')===p.targetBone.join('/'));assert(d,p.id);bone=d.id;const [a,b]=p.sourceBone,L=len(a,b);assert(L>.1&&d.restLength>.1);const ux=(b[0]-a[0])/L,uy=(b[1]-a[1])/L;local=mul([d.restLength/L,0,0,p.widthFactor??1,0,0],E.inverse([ux,uy,-uy,ux,...a]));}
  else if(p.bindJoint==='pelvis'){bone=p.part==='skirt'?'RigidPelvis':'Pelvis';local=tr(p.pivot.map(v=>-v));}
  else throw Error('Unsupported attachment '+p.id);
  const outfits=outfitIds.filter(id=>restPlans[id].some(cmd=>cmd.id===p.id)),ranks=Object.fromEntries(outfits.map(id=>[id,restPlans[id].findIndex(cmd=>cmd.id===p.id)])),command=restPlans[outfits[0]].find(cmd=>cmd.id===p.id),file=command.file;
  assert(outfits.every(id=>restPlans[id].find(cmd=>cmd.id===p.id).file===file));
  parts.push({id:p.id,part:p.part,direction,file,bone,local,outfits,ranks,sourceBone:p.sourceBone,targetBone:p.targetBone,sourceMetadata:p});
  const bytes=fs.readFileSync(V+'/assets/'+file);assert.equal(sha(bytes),source.provenance.textureSha256[file]);
  const dest=R+'/assets/'+file;fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,bytes);textures[file]=sha(bytes);
 }
 const references=[];
 for(let i=0;i<128;i++){const phase=i/16,pose=E.actionPoseWithGait(scene,'heqing',direction,'walk',phase,'s12'),frame=frames(pose);poseRefs.push({direction,action:'walk',phase,joints:pose.joints,frames:frame.globals});references.push({pose,frame});}
 for(const phase of [0,.5,2.5,5.5,7.5]){const pose=E.actionPoseWithGait(scene,'heqing',direction,'idle',phase,'s12');poseRefs.push({direction,action:'idle',phase,joints:pose.joints,frames:frames(pose).globals});}
 for(const outfit of outfitIds){
  neutralRefs.push({direction,outfit,action:'neutral',phase:0,commands:restPlans[outfit]});
  for(const phase of [0,1,2,3,4,5,6,7,.4375,3.4375,7.4375])gpuRefs.push({direction,outfit,action:'walk',phase,commands:E.customCommands(c,direction,outfit,E.actionPoseWithGait(scene,'heqing',direction,'walk',phase,'s12'),'open','original')});
  for(const phase of [0,2.5,5.5])gpuRefs.push({direction,outfit,action:'idle',phase,commands:E.customCommands(c,direction,outfit,E.actionPose(scene,'heqing',direction,'idle',phase),'open','original')});
  for(const {pose,frame} of [...references,{pose:rest,frame:frames(rest)}])for(const cmd of E.customCommands(c,direction,outfit,pose,'open','original')){
   const p=parts.find(p=>p.id===cmd.id),actual=mul(frame.globals[p.bone],p.local);for(let k=0;k<6;k++)maxFactoredMatrixError=Math.max(maxFactoredMatrixError,Math.abs(actual[k]-cmd.matrix[k]));assert.equal(p.ranks[outfit],E.customCommands(c,direction,outfit,pose,'open','original').findIndex(x=>x.id===p.id));
  }
 }
}
assert(maxFactoredMatrixError<1e-10);
const runtime={version:1,character:'heqing',directions,outfits:outfitIds.map(id=>({id,name:id==='original'?'原版衣服':id==='stone-blue-top-four-view'?'石青日常上衣':'月白青瓷汉服'})),defs,views,parts,textures,walk:{stride:12,periodSeconds:.8,lift:.9,reach:.97,minBob:.23},idle:{periodSeconds:2.4,durationsMs:clone(E.ACTIONS.idle.durations),breath:[0,-.3,-.7,-1,-.7,-.25,0,.2],shoulderA:[0,-1,-3,-4,-2,0,2,1],shoulderB:[0,1,2,3,1,0,-1,-.5],elbowA:[0,-4,-7,-9,-5,-1,3,1],elbowB:[0,3,5,7,3,-1,-4,-2]},scope:'One real 15 Bone2D skeleton (14 body + rigid skirt pelvis); four directional rest/local bindings; three outfits; original head/colors; idle and S12 walk. No world locomotion, equipment, dye or face editing.'};
fs.writeFileSync(R+'/data/rig.json',JSON.stringify(runtime,null,2)+'\n');
fs.writeFileSync(R+'/qa/reference-poses.json',JSON.stringify(poseRefs)+'\n');fs.writeFileSync(R+'/qa/reference-gpu.json',JSON.stringify([...neutralRefs,...gpuRefs])+'\n');
if(fs.existsSync(path.resolve(V,'../qa/freeze.json')))fs.copyFileSync(path.resolve(V,'../qa/freeze.json'),R+'/reference/v69-freeze.json');
const audit={source:V,sourceEngineSha256:sha(fs.readFileSync(V+'/rig-engine.js')),sourceStanceSha256:sha(fs.readFileSync(V+'/walk-stance.js')),sourceBundleSha256:sha(fs.readFileSync(V+'/bundle-data.js')),bones:defs.length,parts:parts.length,textures:Object.keys(textures).length,sourcePngByteExact:true,views:directions,walkJointPhasesPerDirection:128,idleJointPhasesPerDirection:5,gpuCases:neutralRefs.length+gpuRefs.length,maxFactoredMatrixError,neutralCases:neutralRefs.length};
fs.writeFileSync(R+'/qa/export-audit.json',JSON.stringify(audit,null,2)+'\n');console.log(audit);

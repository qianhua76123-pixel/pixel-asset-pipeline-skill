#!/bin/zsh
set -eu
V70_PROJECT="$(cd -- "$(dirname -- "$0")" && pwd)"
V70_GODOT="/Users/qian/Applications/Godot-4.6.2.app/Contents/MacOS/Godot"
if [[ ! -x "$V70_GODOT" ]]; then
  print "需要本机 Godot 4.6.2。请用该版本打开项目。"
  exit 1
fi
V70_VERSION="$("$V70_GODOT" --version)"
if [[ "$V70_VERSION" != 4.6.2.* ]]; then
  print "版本不符：$V70_VERSION；此包按 Godot 4.6.2 验证。"
  exit 1
fi
"$V70_GODOT" --headless --path "$V70_PROJECT" --editor --import --quit
exec "$V70_GODOT" --path "$V70_PROJECT"
